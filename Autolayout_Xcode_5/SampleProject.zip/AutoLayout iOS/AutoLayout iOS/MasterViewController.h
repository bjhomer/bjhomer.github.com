//
//  MasterViewController.h
//  AutoLayout iOS
//
//  Created by BJ Homer on 10/2/13.
//  Copyright (c) 2013 BJ Homer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MasterViewController : UITableViewController

@end
