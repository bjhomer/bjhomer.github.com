//
//  Demo4Controller.m
//  AutoLayout iOS
//
//  Created by BJ Homer on 10/9/13.
//  Copyright (c) 2013 BJ Homer. All rights reserved.
//

#import "Demo4Controller.h"

@interface AutoSizingTextView : UITextView <UITextViewDelegate>
@end

@interface Demo4Cell : UITableViewCell
@property IBOutlet UILabel *contentLabel;
@end





@interface Demo4Controller() <UITableViewDataSource, UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet AutoSizingTextView *textView;

@end

@implementation Demo4Controller {
	NSMutableArray *messages;
}

- (void)awakeFromNib
{
	[super awakeFromNib];
	messages = [NSMutableArray new];
}

- (IBAction)tappedAddButton:(id)sender {
	NSString *message = [self.textView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	
	[messages insertObject:message atIndex:0];
	
	self.textView.text = @"";
	
	NSArray *rowsToInsert = @[ [NSIndexPath indexPathForRow:0 inSection:0] ];
	[self.tableView insertRowsAtIndexPaths:rowsToInsert withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [messages count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"ContentCell";
    
    Demo4Cell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
	[self configureCell:cell forIndexPath:indexPath];
	
    return cell;
}


- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	Demo4Cell *cell = [tableView dequeueReusableCellWithIdentifier:@"ContentCell"];
	[self configureCell:cell forIndexPath:indexPath];
	CGSize size = [cell.contentView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize];
	return size.height;
}


- (void)configureCell:(Demo4Cell *)cell forIndexPath:(NSIndexPath *)indexPath
{
	cell.contentLabel.text = messages[indexPath.row];
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[self.view endEditing:YES];
}

@end







@implementation Demo4Cell
@end

@implementation AutoSizingTextView

- (void)awakeFromNib
{
	[super awakeFromNib];
	self.delegate = self;
}

- (void)setText:(NSString *)text
{
	[super setText:text];
	[self invalidateIntrinsicContentSize];
}

- (void)textViewDidChange:(UITextView *)textView
{
	[self invalidateIntrinsicContentSize];
}

- (CGSize)intrinsicContentSize
{
	[self.layoutManager ensureLayoutForTextContainer:self.textContainer];
	CGRect rect = [self.layoutManager usedRectForTextContainer:self.textContainer];
	rect = CGRectIntegral(rect);
	
	rect.size.height += self.textContainerInset.bottom;
	rect.size.height += self.textContainerInset.top;
	rect.size.height += self.contentInset.top;
	rect.size.height += self.contentInset.bottom;
	
	rect.size.width += self.textContainerInset.left;
	rect.size.width += self.textContainerInset.right;
	rect.size.width += self.contentInset.left;
	rect.size.width += self.contentInset.right;
	
	return rect.size;
}


- (void)textViewDidChangeSelection:(UITextView *)textView
{
	// Force layout so the size changes to adapt to the (possibly) new text.
	[self layoutIfNeeded];
	
	CGRect boundingRect = self.layoutManager.extraLineFragmentRect;
	
	if (CGRectIsEmpty(boundingRect)) {
		return;
	}
	
	boundingRect.origin.y += self.textContainerInset.top;
	boundingRect.origin.y += self.textContainerInset.bottom;
	boundingRect.origin.y += self.contentInset.top;
	[self scrollRectToVisible:boundingRect animated:NO];

}

@end