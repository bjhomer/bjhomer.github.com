//: # NSProgress
import UIKit
import XCPlayground

let page = XCPlaygroundPage.currentPage
let progressView = ProgressView()
page.liveView = progressView




//: Updating progress with a simple timer

class TimerUpdater: NSObject {
    var timer: NSTimer?
    var progress: Float = 0 {
        didSet { progressView.progress = progress }
    }
    
    func start() {
        timer = NSTimer.scheduledTimerWithTimeInterval(0.5,
            target: self,
            selector: "updateWithTimer:",
            userInfo: nil,
            repeats: true)
    }
    
    func updateWithTimer(timer: NSTimer) {
        print ("Timer fired")
        progress += 0.05
        if progress > 1.01 {
            page.finishExecution()
        }
    }
}


let updater = TimerUpdater()
updater.start()




//: [Previous](@previous) / [Next](@next)
