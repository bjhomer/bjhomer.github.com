//: # Composition

import UIKit
import XCPlayground

let page = XCPlaygroundPage.currentPage
var progressView = ProgressView()
page.liveView = progressView

let downloadTask = ProgressTask(duration: 4)
let installTask = ProgressTask(duration: 0.25)


//: An NSProgress can contain 'child' progress tasks, which take ownership of some
//: portion of the parent's total unit count
let mainProgress = NSProgress(totalUnitCount: 100)
mainProgress.addChild(downloadTask.progress, withPendingUnitCount: 60)
mainProgress.addChild(installTask.progress, withPendingUnitCount: 20)

progressView.bindToProgress(mainProgress)

let mainObserver = KVOObserver(target: mainProgress, keyPath: "fractionCompleted") { (progress) in
    print(progress)
    if progress.fractionCompleted > 1.0 {
        page.finishExecution()
    }
}

downloadTask.start()
installTask.start()



//: [Previous](@previous) / [Next](@next)
