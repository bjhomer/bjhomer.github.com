//: # Pause / Resume
import UIKit
import XCPlayground

let page = XCPlaygroundPage.currentPage
var progressView = ProgressView()
page.liveView = progressView

let downloadTask = ProgressTask(duration: 3)
let installTask = ProgressTask(duration: 0.25)


let mainProgress = NSProgress(totalUnitCount: 100)
mainProgress.addChild(downloadTask.progress, withPendingUnitCount: 70)
mainProgress.addChild(installTask.progress, withPendingUnitCount: 30)

progressView.bindToProgress(mainProgress)

let mainObserver = KVOObserver(target: mainProgress, keyPath: "fractionCompleted") { (progress) in
    if progress.fractionCompleted > 1.0 {
        page.finishExecution()
    }
}

downloadTask.start()
downloadTask.completionHandler = { installTask.start() }

let oneSec = dispatch_time(DISPATCH_TIME_NOW, Int64(NSEC_PER_SEC))
let twoSec = dispatch_time(DISPATCH_TIME_NOW, Int64(NSEC_PER_SEC * 2))
let mainQueue = dispatch_get_main_queue()

//: Pausing a parent NSProgress also pauses all child progresses.
dispatch_after(oneSec, mainQueue) {
    mainProgress.pause()
}

dispatch_after(twoSec, mainQueue) {
    mainProgress.resume()
}


//: [Previous](@previous) / [Next](@next)
