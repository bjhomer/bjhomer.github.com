//: # A nice API
import UIKit
import XCPlayground

let page = XCPlaygroundPage.currentPage
var progressView = ProgressView()
page.liveView = progressView

//: Let's wrap that ugliness right into our progress view class itself
private var observerContext = 0

extension ProgressView {
    func bindToProgress(progress: NSProgress) {
        progress.addObserver(self, forKeyPath: "fractionCompleted", options: [], context: &observerContext)
    }
    
    public override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
        
        if context == &observerContext,
            let progress = object as? NSProgress {
            self.progress = Float(progress.fractionCompleted)
        }
        else {
            super.observeValueForKeyPath(keyPath, ofObject: object, change: change, context: context)
        }
    }
}


//: No more explicit binding; much cleaner!


class ProgressUpdater: NSObject {
    var timer: NSTimer?
    var progress = NSProgress(totalUnitCount: 100)
    
    func start() {
        timer = NSTimer.scheduledTimerWithTimeInterval(0.5,
            target: self,
            selector: "updateWithTimer:",
            userInfo: nil,
            repeats: true)

        // So nice!
        progressView.bindToProgress(progress)
    }
    
    func updateWithTimer(timer: NSTimer) {
        progress.completedUnitCount += 5
        if progress.fractionCompleted >= 1.01 {
            page.finishExecution()
        }
    }
}


let updater = ProgressUpdater()
updater.start()

//: [Progress](@previous) / [Next](@next)
