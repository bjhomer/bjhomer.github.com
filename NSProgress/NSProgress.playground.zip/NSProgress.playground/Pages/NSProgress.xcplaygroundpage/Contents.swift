//: # NSProgress
import UIKit
import XCPlayground

let page = XCPlaygroundPage.currentPage
let progressView = ProgressView()
page.liveView = progressView



//: Now let's use NSProgress
private var observerContext = 0

class ProgressUpdater: NSObject {
    var timer: NSTimer?
    var progress = NSProgress(totalUnitCount: 100)
    
    func start() {
        timer = NSTimer.scheduledTimerWithTimeInterval(0.5,
            target: self,
            selector: "updateWithTimer:",
            userInfo: nil,
            repeats: true)
        
        // Observe `NSProgress.fractionCompleted`
        progress.addObserver(self, forKeyPath: "fractionCompleted", options: [], context: &observerContext)
    }
    
    func updateWithTimer(timer: NSTimer) {
        progress.completedUnitCount += 5
        if progress.fractionCompleted >= 1.0 {
            page.finishExecution()
        }
    }
    
    // Yeah, we need to add this huge method too. Kinda lame.
    override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
        
        if context == &observerContext {
            progressView.progress = Float(progress.fractionCompleted)
        }
    }
}


let updater = ProgressUpdater()
updater.start()


//: [Progress](@previous) / [Next](@next)
