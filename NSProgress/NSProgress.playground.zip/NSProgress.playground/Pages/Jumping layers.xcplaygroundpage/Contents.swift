//: # Jumping layers
import UIKit
import XCPlayground

let page = XCPlaygroundPage.currentPage
var progressView = ProgressView()
page.liveView = progressView




public func layer1() {
    layer2()
}

func layer2() {
    let imageURL = NSBundle.mainBundle().URLForResource("Orion", withExtension: "JPG")!
    let image = UIImage(contentsOfFile: imageURL.path!)!
    image
    
    layer3()
}

func layer3() {
    let task = ProgressTask(duration: 2)
    task.start()
}


let mainProgress = NSProgress(totalUnitCount: 100)
progressView.bindToProgress(mainProgress)
let mainObserver = KVOObserver(target: mainProgress, keyPath: "fractionCompleted") { (progress) in
    if progress.fractionCompleted > 1.0 {
        page.finishExecution()
    }
}

do {
    mainProgress.becomeCurrentWithPendingUnitCount(30)
    layer1()
    mainProgress.resignCurrent()
    
    mainProgress.becomeCurrentWithPendingUnitCount(70)
    layer1()
    mainProgress.resignCurrent()
}


//: [Previous](@previous) / [Next](@next)
