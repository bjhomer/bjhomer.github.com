//: # ProgressTask
import UIKit
import XCPlayground

let page = XCPlaygroundPage.currentPage
var progressView = ProgressView()
page.liveView = progressView

//: Here's a nice encapsulation of a task that reports progress.
//: It conforms to NSProgessReporting, so it's easy to 
let task = ProgressTask(duration: 4)
task.completionHandler = { page.finishExecution() }

progressView.bindToProgress(task.progress)

task.start()



//: [Progress](@previous) / [Next](@next)
