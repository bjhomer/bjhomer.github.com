//: # NSProgress
import UIKit
import XCPlayground

let page = XCPlaygroundPage.currentPage
let progressView = ProgressView()
page.liveView = progressView

progressView.progress = 0.2
//: [Next](@next)
