import Foundation

private var myContext = 0

public class KVOObserver<T: NSObject> : NSObject {
    private let handler: (T)->Void
    
    public init(target: T, keyPath: String, handler: (T)->Void) {
        self.handler = handler
        super.init()
        target.addObserver(self, forKeyPath: keyPath, options: [], context: &myContext)
    }
    
    public override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
        guard context == &myContext else {
            super.observeValueForKeyPath(keyPath, ofObject: object, change: change, context: context)
            return
        }
        handler(object as! T)
    }
}