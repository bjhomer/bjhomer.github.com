import Foundation

public class ProgressTask: NSObject, NSProgressReporting {
    let dispatch_timer: dispatch_source_t
    let duration: NSTimeInterval
    public var progress = NSProgress(totalUnitCount: 100)
    public var completionHandler: (()->Void)?
    
    private let ticsPerSec: UInt64 = 20
    
    public init(duration: NSTimeInterval) {
        self.duration = duration
        self.dispatch_timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_global_queue(QOS_CLASS_DEFAULT, 0))
        dispatch_source_set_timer(self.dispatch_timer, DISPATCH_TIME_NOW, NSEC_PER_SEC/ticsPerSec, NSEC_PER_SEC/ticsPerSec)
        super.init()
    }
    
    public func start() {
        let expectedTics = Double(ticsPerSec) * duration
        var tics: Double = 0
        
        dispatch_source_set_event_handler(self.dispatch_timer) {
            
            if self.progress.paused {
                return
            }
            
            tics += 1
            
            var completedCount = Int64(tics / expectedTics * 100)
            if (completedCount > self.progress.totalUnitCount) {
                completedCount = self.progress.totalUnitCount
            }
            self.progress.completedUnitCount = completedCount
            
            
            
            if self.progress.fractionCompleted >= 1.0 {
                dispatch_source_cancel(self.dispatch_timer)
                self.completionHandler?()
            }
        }
        dispatch_resume(dispatch_timer)
    }
}