import UIKit
import CoreGraphics

public class ProgressView: UIView {
    public var progress: Float = 0 {
        didSet { setNeedsDisplay() }
    }
    
    public init() {
        super.init(frame: CGRectMake(0,0,300,80))
    }

    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override public func drawRect(dirtyRect: CGRect) {
        let width = bounds.width
        let filledWidth = width * CGFloat(progress)
        let (slice, remainder) = bounds.divide(filledWidth, fromEdge: .MinXEdge)
    
        let context = UIGraphicsGetCurrentContext()
        
        UIColor.blueColor().setFill()
        CGContextFillRect(context, slice)
        
        UIColor.grayColor().setFill()
        CGContextFillRect(context, remainder)
    }
}

private var observerContext = 0
extension ProgressView {
    public func bindToProgress(progress: NSProgress) {
        progress.addObserver(self, forKeyPath: "fractionCompleted", options: [], context: &observerContext)
    }
    
    public override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
        if context == &observerContext,
            let progress = object as? NSProgress
        {
            dispatch_async(dispatch_get_main_queue()) {
                self.progress = Float(progress.fractionCompleted)
            }
            
            if progress.totalUnitCount == progress.completedUnitCount {
                progress.removeObserver(self, forKeyPath: "fractionCompleted", context: &observerContext)
            }
        }
        else {
            super.observeValueForKeyPath(keyPath, ofObject: object, change: change, context: context)
        }
    }
}